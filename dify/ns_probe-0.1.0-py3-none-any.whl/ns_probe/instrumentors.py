"""
Auto-instrumentors for common libraries.

This module provides automatic instrumentation for libraries commonly
used with AI agents:
- OpenAI (chat completions, embeddings)
- Anthropic (messages)
- HTTPX/Requests (HTTP calls)
- LangChain (if installed)
- LlamaIndex (if installed)

The goal is to provide out-of-the-box visibility into LLM calls and
external HTTP requests without requiring code changes.

Instrumentation Strategy:
    We attempt to use OpenLLMetry instrumentors where available,
    falling back to simple monkey-patching for unsupported libraries.
"""

from __future__ import annotations

import logging
import functools
import time
from typing import Any, Callable, Optional, TypeVar

from .tracer import get_tracer
from .span import SpanKind

logger = logging.getLogger("ns_probe.instrumentors")

F = TypeVar('F', bound=Callable[..., Any])

# URLs that should NOT be traced by the HTTP instrumentors.
# These are either internal (observability pipeline) or already
# covered by a dedicated LLM instrumentor.
_EXCLUDED_URL_SUBSTRINGS = (
    "neo_observe",
    "/v1/traces",
    "/v1/logs",
    "api.openai.com",
    "api.anthropic.com",
    "localhost:4318",
    "localhost:4317",
    "host.docker.internal:4318",
    "host.docker.internal:4317",
    "host.docker.internal:8080",
)


def _should_skip_url(url: str) -> bool:
    """Return True if the URL should NOT produce an HTTP span."""
    url_lower = url.lower()
    return any(sub in url_lower for sub in _EXCLUDED_URL_SUBSTRINGS)


def instrument_all() -> None:
    """
    Instrument all supported libraries.
    
    This is called automatically by ns-probe-run unless --no-auto-instrument
    is specified.
    """
    # Track what was instrumented
    instrumented = []
    failed = []
    
    # Try OpenLLMetry instrumentors first (they're well-maintained)
    if _try_openllmetry():
        instrumented.append("OpenLLMetry (OpenAI, Anthropic, LangChain, etc.)")
    else:
        # Fallback to our own instrumentors
        if _instrument_openai():
            instrumented.append("OpenAI")
        else:
            failed.append("OpenAI")
        
        if _instrument_anthropic():
            instrumented.append("Anthropic")
        else:
            failed.append("Anthropic")
    
    # LangGraph instrumentation (context propagation through StateGraph)
    # This is critical - LangGraph breaks contextvars, we fix it
    from .langgraph_instrumentor import instrument_langgraph
    if instrument_langgraph():
        instrumented.append("LangGraph")
    
    # HTTP clients (usually not covered by OpenLLMetry)
    if _instrument_httpx():
        instrumented.append("httpx")
    
    if _instrument_requests():
        instrumented.append("requests")
    
    # Database instrumentation (asyncpg, psycopg2)
    if _instrument_asyncpg():
        instrumented.append("asyncpg")
    
    if _instrument_psycopg2():
        instrumented.append("psycopg2")
    
    if instrumented:
        logger.info(f"Instrumented: {', '.join(instrumented)}")
    
    if failed:
        logger.debug(f"Could not instrument (not installed?): {', '.join(failed)}")


def _try_openllmetry() -> bool:
    """
    Try to use OpenLLMetry's instrumentors.
    
    Disabled: Traceloop.init() creates a separate TracerProvider that
    produces orphan spans instead of child spans under ns_probe's root.
    ns_probe's built-in instrumentors (below) use get_tracer() which
    shares the same trace context, keeping LLM spans as children.
    """
    logger.debug("Skipping OpenLLMetry (uses separate TracerProvider); using built-in instrumentors")
    return False


def _instrument_openai() -> bool:
    """
    Instrument OpenAI library.
    
    Wraps:
        - client.chat.completions.create()
        - client.embeddings.create()
    
    Returns:
        True if instrumentation succeeded
    """
    try:
        import openai
        
        # Check if already instrumented
        if hasattr(openai, '_ns_probe_instrumented'):
            return True
        
        tracer = get_tracer("ns_probe.openai")
        
        # Instrument the completions create method
        original_create = openai.resources.chat.completions.Completions.create
        
        @functools.wraps(original_create)
        def traced_create(self: Any, *args: Any, **kwargs: Any) -> Any:
            model = kwargs.get('model', 'unknown')
            
            with tracer.start_span("llm.call", kind=SpanKind.CLIENT) as span:
                span.set_attributes({
                    'gen_ai.system': 'openai',
                    'gen_ai.request.model': model,
                })
                
                # Capture messages if present (truncated)
                if 'messages' in kwargs:
                    messages = kwargs['messages']
                    span.set_attribute('gen_ai.prompt', _format_messages(messages))
                
                start_time = time.time()
                result = original_create(self, *args, **kwargs)
                latency_ms = (time.time() - start_time) * 1000
                
                span.set_attribute('gen_ai.latency_ms', latency_ms)
                
                # Extract response metadata
                if hasattr(result, 'usage'):
                    span.set_attributes({
                        'gen_ai.usage.input_tokens': result.usage.prompt_tokens,
                        'gen_ai.usage.output_tokens': result.usage.completion_tokens,
                    })
                    
                    # Extract cached tokens if available
                    if hasattr(result.usage, 'prompt_tokens_details') and result.usage.prompt_tokens_details:
                        cached = getattr(result.usage.prompt_tokens_details, 'cached_tokens', 0)
                        if cached:
                            span.set_attribute('gen_ai.usage.cached_tokens', cached)
                            # Actual non-cached input is total - cached
                            span.set_attribute('gen_ai.usage.input_tokens', result.usage.prompt_tokens - cached)

                    # GPT-5/o-series: Extract reasoning tokens from completion_tokens_details
                    if hasattr(result.usage, 'completion_tokens_details'):
                        details = result.usage.completion_tokens_details
                        if details and hasattr(details, 'reasoning_tokens'):
                            reasoning_tokens = details.reasoning_tokens or 0
                            span.set_attribute('gen_ai.usage.reasoning_tokens', reasoning_tokens)
                
                if hasattr(result, 'model'):
                    span.set_attribute('gen_ai.response.model', result.model)
                
                if hasattr(result, 'choices') and result.choices:
                    choice = result.choices[0]
                    if hasattr(choice, 'finish_reason'):
                        span.set_attribute('gen_ai.response.finish_reason', choice.finish_reason)
                    if hasattr(choice, 'message') and hasattr(choice.message, 'content'):
                        span.set_attribute('gen_ai.completion', _truncate(choice.message.content or '', 1000))
                
                return result
        
        openai.resources.chat.completions.Completions.create = traced_create
        
        # Instrument Responses API (GPT-5 visible reasoning)
        try:
            original_responses_create = openai.resources.responses.Responses.create
            
            @functools.wraps(original_responses_create)
            def traced_responses_create(self: Any, *args: Any, **kwargs: Any) -> Any:
                model = kwargs.get('model', 'unknown')
                
                with tracer.start_span("llm.call", kind=SpanKind.CLIENT) as span:
                    span.set_attributes({
                        'gen_ai.system': 'openai',
                        'gen_ai.request.model': model,
                    })
                    
                    if 'messages' in kwargs:
                        span.set_attribute('gen_ai.prompt', _format_messages(kwargs['messages']))
                    elif 'input' in kwargs:
                        # Capture input, handling list of messages or string
                        inp = kwargs['input']
                        if isinstance(inp, list):
                            span.set_attribute('gen_ai.prompt', _format_messages(inp))
                        else:
                            span.set_attribute('gen_ai.prompt', _truncate(str(inp), 1000))
                    
                    start_time = time.time()
                    result = original_responses_create(self, *args, **kwargs)
                    latency_ms = (time.time() - start_time) * 1000
                    
                    span.set_attribute('gen_ai.latency_ms', latency_ms)
                    
                    # Capture visible reasoning if available
                    if hasattr(result, 'reasoning_summary'):
                         span.set_attribute('gen_ai.usage.reasoning_text', result.reasoning_summary)
                    
                    if hasattr(result, 'output_text'):
                        span.set_attribute('gen_ai.completion', _truncate(result.output_text or '', 1000))

                    if hasattr(result, 'usage'):
                         span.set_attributes({
                            'gen_ai.usage.input_tokens': getattr(result.usage, 'input_tokens', 0),
                            'gen_ai.usage.output_tokens': getattr(result.usage, 'output_tokens', 0),
                         })

                    return result
            
            openai.resources.responses.Responses.create = traced_responses_create
            logger.debug("Instrumented OpenAI Responses API")
            
        except AttributeError:
             # Responses API not available in this SDK version
             pass

        # Also instrument async version
        try:
            original_acreate = openai.resources.chat.completions.AsyncCompletions.create
            
            @functools.wraps(original_acreate)
            async def traced_acreate(self: Any, *args: Any, **kwargs: Any) -> Any:
                model = kwargs.get('model', 'unknown')
                
                with tracer.start_span("llm.call", kind=SpanKind.CLIENT) as span:
                    span.set_attributes({
                        'gen_ai.system': 'openai',
                        'gen_ai.request.model': model,
                    })
                    
                    if 'messages' in kwargs:
                        span.set_attribute('gen_ai.prompt', _format_messages(kwargs['messages']))
                    
                    start_time = time.time()
                    result = await original_acreate(self, *args, **kwargs)
                    latency_ms = (time.time() - start_time) * 1000
                    
                    span.set_attribute('gen_ai.latency_ms', latency_ms)
                    
                    if hasattr(result, 'usage'):
                        span.set_attributes({
                            'gen_ai.usage.input_tokens': result.usage.prompt_tokens,
                            'gen_ai.usage.output_tokens': result.usage.completion_tokens,
                        })
                        
                        # Extract cached tokens if available
                        if hasattr(result.usage, 'prompt_tokens_details') and result.usage.prompt_tokens_details:
                            cached = getattr(result.usage.prompt_tokens_details, 'cached_tokens', 0)
                            if cached:
                                span.set_attribute('gen_ai.usage.cached_tokens', cached)
                                # Actual non-cached input is total - cached
                                span.set_attribute('gen_ai.usage.input_tokens', result.usage.prompt_tokens - cached)

                    
                    if hasattr(result, 'model'):
                        span.set_attribute('gen_ai.response.model', result.model)
                    
                    return result
            
            openai.resources.chat.completions.AsyncCompletions.create = traced_acreate
        except AttributeError:
            pass  # Async not available in this version
        
        openai._ns_probe_instrumented = True  # type: ignore
        logger.debug("Instrumented OpenAI")
        return True
        
    except ImportError:
        return False
    except Exception as e:
        logger.debug(f"Failed to instrument OpenAI: {e}")
        return False


def _instrument_anthropic() -> bool:
    """
    Instrument Anthropic library.
    
    Wraps:
        - client.messages.create()
    
    Returns:
        True if instrumentation succeeded
    """
    try:
        import anthropic
        
        if hasattr(anthropic, '_ns_probe_instrumented'):
            return True
        
        tracer = get_tracer("ns_probe.anthropic")
        
        original_create = anthropic.resources.Messages.create
        
        @functools.wraps(original_create)
        def traced_create(self: Any, *args: Any, **kwargs: Any) -> Any:
            model = kwargs.get('model', 'unknown')
            
            with tracer.start_span("llm.call", kind=SpanKind.CLIENT) as span:
                span.set_attributes({
                    'gen_ai.system': 'anthropic',
                    'gen_ai.request.model': model,
                })
                
                if 'messages' in kwargs:
                    span.set_attribute('gen_ai.prompt', _format_messages(kwargs['messages']))
                
                start_time = time.time()
                result = original_create(self, *args, **kwargs)
                latency_ms = (time.time() - start_time) * 1000
                
                span.set_attribute('gen_ai.latency_ms', latency_ms)
                
                if hasattr(result, 'usage'):
                    span.set_attributes({
                        'gen_ai.usage.input_tokens': result.usage.input_tokens,
                        'gen_ai.usage.output_tokens': result.usage.output_tokens,
                    })
                
                if hasattr(result, 'model'):
                    span.set_attribute('gen_ai.response.model', result.model)
                
                if hasattr(result, 'stop_reason'):
                    span.set_attribute('gen_ai.response.finish_reason', result.stop_reason)
                
                return result
        
        anthropic.resources.Messages.create = traced_create
        anthropic._ns_probe_instrumented = True  # type: ignore
        
        logger.debug("Instrumented Anthropic")
        return True
        
    except ImportError:
        return False
    except Exception as e:
        logger.debug(f"Failed to instrument Anthropic: {e}")
        return False


def _instrument_httpx() -> bool:
    """
    Instrument httpx library.
    
    Wraps:
        - client.request()
        - client.get/post/put/delete/etc.
    
    Returns:
        True if instrumentation succeeded
    """
    try:
        import httpx
        
        if hasattr(httpx, '_ns_probe_instrumented'):
            return True
        
        tracer = get_tracer("ns_probe.httpx")
        
        original_send = httpx.Client.send
        
        @functools.wraps(original_send)
        def traced_send(self: Any, request: Any, *args: Any, **kwargs: Any) -> Any:
            if _should_skip_url(str(request.url)):
                return original_send(self, request, *args, **kwargs)
            
            span_name = f"HTTP {request.method}"
            
            with tracer.start_span(span_name, kind=SpanKind.CLIENT) as span:
                span.set_attributes({
                    'http.method': request.method,
                    'http.url': str(request.url),
                    'http.host': request.url.host,
                })
                
                start_time = time.time()
                response = original_send(self, request, *args, **kwargs)
                latency_ms = (time.time() - start_time) * 1000
                
                span.set_attributes({
                    'http.status_code': response.status_code,
                    'http.latency_ms': latency_ms,
                })
                
                return response
        
        httpx.Client.send = traced_send
        
        # Also instrument async client
        try:
            original_async_send = httpx.AsyncClient.send
            
            @functools.wraps(original_async_send)
            async def traced_async_send(self: Any, request: Any, *args: Any, **kwargs: Any) -> Any:
                if _should_skip_url(str(request.url)):
                    return await original_async_send(self, request, *args, **kwargs)
                
                span_name = f"HTTP {request.method}"
                
                with tracer.start_span(span_name, kind=SpanKind.CLIENT) as span:
                    span.set_attributes({
                        'http.method': request.method,
                        'http.url': str(request.url),
                        'http.host': request.url.host,
                    })
                    
                    start_time = time.time()
                    response = await original_async_send(self, request, *args, **kwargs)
                    latency_ms = (time.time() - start_time) * 1000
                    
                    span.set_attributes({
                        'http.status_code': response.status_code,
                        'http.latency_ms': latency_ms,
                    })
                    
                    return response
            
            httpx.AsyncClient.send = traced_async_send
        except AttributeError:
            pass
        
        httpx._ns_probe_instrumented = True  # type: ignore
        logger.debug("Instrumented httpx")
        return True
        
    except ImportError:
        return False
    except Exception as e:
        logger.debug(f"Failed to instrument httpx: {e}")
        return False


def _instrument_requests() -> bool:
    """
    Instrument requests library.
    
    Wraps:
        - requests.Session.request()
    
    Returns:
        True if instrumentation succeeded
    """
    try:
        import requests
        
        if hasattr(requests, '_ns_probe_instrumented'):
            return True
        
        tracer = get_tracer("ns_probe.requests")
        
        original_request = requests.Session.request
        
        @functools.wraps(original_request)
        def traced_request(self: Any, method: str, url: str, *args: Any, **kwargs: Any) -> Any:
            if _should_skip_url(url):
                return original_request(self, method, url, *args, **kwargs)
            
            span_name = f"HTTP {method}"
            
            with tracer.start_span(span_name, kind=SpanKind.CLIENT) as span:
                span.set_attributes({
                    'http.method': method,
                    'http.url': url,
                })
                
                start_time = time.time()
                response = original_request(self, method, url, *args, **kwargs)
                latency_ms = (time.time() - start_time) * 1000
                
                span.set_attributes({
                    'http.status_code': response.status_code,
                    'http.latency_ms': latency_ms,
                })
                
                return response
        
        requests.Session.request = traced_request
        requests._ns_probe_instrumented = True  # type: ignore
        
        logger.debug("Instrumented requests")
        return True
        
    except ImportError:
        return False
    except Exception as e:
        logger.debug(f"Failed to instrument requests: {e}")
        return False


def _format_messages(messages: list) -> str:
    """Format chat messages for span attribute."""
    try:
        formatted = []
        for msg in messages[:5]:  # Limit to first 5 messages
            if isinstance(msg, dict):
                role = msg.get('role', 'unknown')
                content = msg.get('content', '')
            else:
                role = getattr(msg, 'role', 'unknown')
                content = getattr(msg, 'content', '')
            
            formatted.append(f"[{role}]: {_truncate(str(content), 200)}")
        
        if len(messages) > 5:
            formatted.append(f"... and {len(messages) - 5} more messages")
        
        return '\n'.join(formatted)
    except Exception:
        return str(messages)[:500]


def _truncate(s: str, max_len: int) -> str:
    """Truncate string to max length."""
    if len(s) <= max_len:
        return s
    return s[:max_len - 3] + "..."


def _instrument_asyncpg() -> bool:
    """
    Instrument asyncpg library for PostgreSQL.
    
    Wraps:
        - asyncpg.connect()
        - asyncpg.create_pool()
        - Connection.execute(), fetch(), fetchrow(), fetchval()
    
    Returns:
        True if instrumentation succeeded
    """
    try:
        import asyncpg
        
        if hasattr(asyncpg, '_ns_probe_instrumented'):
            return True
        
        tracer = get_tracer("ns_probe.asyncpg")
        from .span import StatusCode
        
        # Instrument connect()
        original_connect = asyncpg.connect
        
        @functools.wraps(original_connect)
        async def traced_connect(*args: Any, **kwargs: Any) -> Any:
            # Extract connection info for span attributes
            host = kwargs.get('host', args[0] if args else 'localhost')
            port = kwargs.get('port', 5432)
            database = kwargs.get('database', kwargs.get('dbname', 'unknown'))
            user = kwargs.get('user', 'unknown')
            
            with tracer.start_span("db.connect", kind=SpanKind.CLIENT) as span:
                span.set_attributes({
                    'db.system': 'postgresql',
                    'db.name': str(database),
                    'db.user': str(user),
                    'net.peer.name': str(host),
                    'net.peer.port': port,
                    'db.operation': 'connect',
                })
                
                start_time = time.time()
                try:
                    result = await original_connect(*args, **kwargs)
                    latency_ms = (time.time() - start_time) * 1000
                    span.set_attribute('db.latency_ms', latency_ms)
                    span.set_attribute('db.connection.status', 'success')
                    return result
                except Exception as e:
                    latency_ms = (time.time() - start_time) * 1000
                    span.set_attribute('db.latency_ms', latency_ms)
                    span.set_attribute('db.connection.status', 'error')
                    span.set_attribute('db.error.message', str(e))
                    span.set_attribute('db.error.type', type(e).__name__)
                    span.set_status(StatusCode.ERROR, str(e))
                    raise
        
        asyncpg.connect = traced_connect
        
        # Instrument create_pool()
        original_create_pool = asyncpg.create_pool
        
        @functools.wraps(original_create_pool)
        async def traced_create_pool(*args: Any, **kwargs: Any) -> Any:
            host = kwargs.get('host', args[0] if args else 'localhost')
            database = kwargs.get('database', kwargs.get('dsn', 'unknown'))
            
            with tracer.start_span("db.pool.create", kind=SpanKind.CLIENT) as span:
                span.set_attributes({
                    'db.system': 'postgresql',
                    'db.name': str(database),
                    'net.peer.name': str(host),
                    'db.operation': 'create_pool',
                })
                
                start_time = time.time()
                try:
                    result = await original_create_pool(*args, **kwargs)
                    latency_ms = (time.time() - start_time) * 1000
                    span.set_attribute('db.latency_ms', latency_ms)
                    span.set_attribute('db.pool.status', 'success')
                    return result
                except Exception as e:
                    latency_ms = (time.time() - start_time) * 1000
                    span.set_attribute('db.latency_ms', latency_ms)
                    span.set_attribute('db.pool.status', 'error')
                    span.set_attribute('db.error.message', str(e))
                    span.set_attribute('db.error.type', type(e).__name__)
                    span.set_status(StatusCode.ERROR, str(e))
                    raise
        
        asyncpg.create_pool = traced_create_pool
        
        # Instrument Connection methods
        try:
            original_execute = asyncpg.Connection.execute
            original_fetch = asyncpg.Connection.fetch
            original_fetchrow = asyncpg.Connection.fetchrow
            original_fetchval = asyncpg.Connection.fetchval
            
            @functools.wraps(original_execute)
            async def traced_execute(self: Any, query: str, *args: Any, **kwargs: Any) -> Any:
                with tracer.start_span("db.execute", kind=SpanKind.CLIENT) as span:
                    span.set_attributes({
                        'db.system': 'postgresql',
                        'db.statement': _truncate(query, 500),
                        'db.operation': 'execute',
                    })
                    start_time = time.time()
                    try:
                        result = await original_execute(self, query, *args, **kwargs)
                        span.set_attribute('db.latency_ms', (time.time() - start_time) * 1000)
                        return result
                    except Exception as e:
                        span.set_attribute('db.error.message', str(e))
                        span.set_status(StatusCode.ERROR, str(e))
                        raise
            
            @functools.wraps(original_fetch)
            async def traced_fetch(self: Any, query: str, *args: Any, **kwargs: Any) -> Any:
                with tracer.start_span("db.fetch", kind=SpanKind.CLIENT) as span:
                    span.set_attributes({
                        'db.system': 'postgresql',
                        'db.statement': _truncate(query, 500),
                        'db.operation': 'fetch',
                    })
                    start_time = time.time()
                    try:
                        result = await original_fetch(self, query, *args, **kwargs)
                        span.set_attribute('db.latency_ms', (time.time() - start_time) * 1000)
                        span.set_attribute('db.row_count', len(result) if result else 0)
                        return result
                    except Exception as e:
                        span.set_attribute('db.error.message', str(e))
                        span.set_status(StatusCode.ERROR, str(e))
                        raise
            
            @functools.wraps(original_fetchrow)
            async def traced_fetchrow(self: Any, query: str, *args: Any, **kwargs: Any) -> Any:
                with tracer.start_span("db.fetchrow", kind=SpanKind.CLIENT) as span:
                    span.set_attributes({
                        'db.system': 'postgresql',
                        'db.statement': _truncate(query, 500),
                        'db.operation': 'fetchrow',
                    })
                    start_time = time.time()
                    try:
                        result = await original_fetchrow(self, query, *args, **kwargs)
                        span.set_attribute('db.latency_ms', (time.time() - start_time) * 1000)
                        return result
                    except Exception as e:
                        span.set_attribute('db.error.message', str(e))
                        span.set_status(StatusCode.ERROR, str(e))
                        raise
            
            @functools.wraps(original_fetchval)
            async def traced_fetchval(self: Any, query: str, *args: Any, **kwargs: Any) -> Any:
                with tracer.start_span("db.fetchval", kind=SpanKind.CLIENT) as span:
                    span.set_attributes({
                        'db.system': 'postgresql',
                        'db.statement': _truncate(query, 500),
                        'db.operation': 'fetchval',
                    })
                    start_time = time.time()
                    try:
                        result = await original_fetchval(self, query, *args, **kwargs)
                        span.set_attribute('db.latency_ms', (time.time() - start_time) * 1000)
                        return result
                    except Exception as e:
                        span.set_attribute('db.error.message', str(e))
                        span.set_status(StatusCode.ERROR, str(e))
                        raise
            
            asyncpg.Connection.execute = traced_execute
            asyncpg.Connection.fetch = traced_fetch
            asyncpg.Connection.fetchrow = traced_fetchrow
            asyncpg.Connection.fetchval = traced_fetchval
            
        except AttributeError:
            pass  # Connection class not available
        
        asyncpg._ns_probe_instrumented = True  # type: ignore
        logger.debug("Instrumented asyncpg")
        return True
        
    except ImportError:
        return False
    except Exception as e:
        logger.debug(f"Failed to instrument asyncpg: {e}")
        return False


def _instrument_psycopg2() -> bool:
    """
    Instrument psycopg2 library for PostgreSQL.
    
    Wraps:
        - psycopg2.connect()
        - Cursor.execute(), executemany(), fetchone(), fetchall(), fetchmany()
    
    Returns:
        True if instrumentation succeeded
    """
    try:
        import psycopg2
        
        if hasattr(psycopg2, '_ns_probe_instrumented'):
            return True
        
        tracer = get_tracer("ns_probe.psycopg2")
        from .span import StatusCode
        
        # Instrument connect()
        original_connect = psycopg2.connect
        
        @functools.wraps(original_connect)
        def traced_connect(*args: Any, **kwargs: Any) -> Any:
            # Extract connection info
            host = kwargs.get('host', 'localhost')
            port = kwargs.get('port', 5432)
            database = kwargs.get('database', kwargs.get('dbname', 'unknown'))
            user = kwargs.get('user', 'unknown')
            
            # Also check DSN string
            if args and isinstance(args[0], str):
                dsn = args[0]
                database = dsn  # Use DSN as database identifier
            
            with tracer.start_span("db.connect", kind=SpanKind.CLIENT) as span:
                span.set_attributes({
                    'db.system': 'postgresql',
                    'db.name': str(database),
                    'db.user': str(user),
                    'net.peer.name': str(host),
                    'net.peer.port': port,
                    'db.operation': 'connect',
                })
                
                start_time = time.time()
                try:
                    result = original_connect(*args, **kwargs)
                    latency_ms = (time.time() - start_time) * 1000
                    span.set_attribute('db.latency_ms', latency_ms)
                    span.set_attribute('db.connection.status', 'success')
                    return result
                except Exception as e:
                    latency_ms = (time.time() - start_time) * 1000
                    span.set_attribute('db.latency_ms', latency_ms)
                    span.set_attribute('db.connection.status', 'error')
                    span.set_attribute('db.error.message', str(e))
                    span.set_attribute('db.error.type', type(e).__name__)
                    span.set_status(StatusCode.ERROR, str(e))
                    raise
        
        psycopg2.connect = traced_connect
        
        # Instrument Cursor methods
        try:
            from psycopg2.extensions import cursor as CursorClass
            
            original_execute = CursorClass.execute
            original_executemany = CursorClass.executemany
            
            @functools.wraps(original_execute)
            def traced_cursor_execute(self: Any, query: Any, vars: Any = None) -> Any:
                query_str = str(query) if query else ''
                
                with tracer.start_span("db.execute", kind=SpanKind.CLIENT) as span:
                    span.set_attributes({
                        'db.system': 'postgresql',
                        'db.statement': _truncate(query_str, 500),
                        'db.operation': 'execute',
                    })
                    start_time = time.time()
                    try:
                        result = original_execute(self, query, vars)
                        span.set_attribute('db.latency_ms', (time.time() - start_time) * 1000)
                        if hasattr(self, 'rowcount') and self.rowcount >= 0:
                            span.set_attribute('db.row_count', self.rowcount)
                        return result
                    except Exception as e:
                        span.set_attribute('db.error.message', str(e))
                        span.set_status(StatusCode.ERROR, str(e))
                        raise
            
            @functools.wraps(original_executemany)
            def traced_cursor_executemany(self: Any, query: Any, vars_list: Any) -> Any:
                query_str = str(query) if query else ''
                
                with tracer.start_span("db.executemany", kind=SpanKind.CLIENT) as span:
                    span.set_attributes({
                        'db.system': 'postgresql',
                        'db.statement': _truncate(query_str, 500),
                        'db.operation': 'executemany',
                        'db.batch_size': len(vars_list) if vars_list else 0,
                    })
                    start_time = time.time()
                    try:
                        result = original_executemany(self, query, vars_list)
                        span.set_attribute('db.latency_ms', (time.time() - start_time) * 1000)
                        return result
                    except Exception as e:
                        span.set_attribute('db.error.message', str(e))
                        span.set_status(StatusCode.ERROR, str(e))
                        raise
            
            CursorClass.execute = traced_cursor_execute
            CursorClass.executemany = traced_cursor_executemany
            
        except (ImportError, AttributeError):
            pass  # Cursor class not available
        
        psycopg2._ns_probe_instrumented = True  # type: ignore
        logger.debug("Instrumented psycopg2")
        return True
        
    except ImportError:
        return False
    except Exception as e:
        logger.debug(f"Failed to instrument psycopg2: {e}")
        return False
