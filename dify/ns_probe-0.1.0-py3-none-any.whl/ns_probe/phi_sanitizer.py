"""
PHI (Protected Health Information) Sanitization for ns_probe.

This module is the **single entry-point** for all PHI redaction inside the
SDK.  It sits between the span/log data and the export layer.

Two engines are supported (auto-selected):

1. **Presidio (NLP)** – Microsoft Presidio + spaCy.  Detects PHI in *any*
   string (names, SSNs, phone numbers, dates …) regardless of which
   attribute key holds the value.  This is the **recommended** engine for
   healthcare workloads.

2. **Key-matching (regex)** – lightweight fallback that replaces values
   whose *attribute key* matches a configurable set of sensitive patterns.
   Zero external dependencies.

Engine selection:
    * If Presidio libs are importable **and** PHI is enabled →  Presidio.
    * Otherwise → key-matching.
    * ``NS_PROBE_PHI_ENGINE=keys`` forces key-matching even when Presidio
      is installed (useful for latency-sensitive batch pipelines).

Configuration priority (highest → lowest):
    1. ``configure_phi()`` programmatic call
    2. Environment variables
    3. Built-in defaults

Environment Variables:
    NS_PROBE_PHI_ENABLED:
        Master switch (default: ``false``).
    NS_PROBE_PHI_ENGINE:
        ``presidio`` (default if libs present) or ``keys``.
    NS_PROBE_PHI_SENSITIVE_KEYS:
        Comma-separated list of attribute key patterns (key-matching engine).
    NS_PROBE_PHI_STRATEGY:
        ``redact``  (default) – replace with ``[REDACTED]``
        ``hash``              – replace with ``sha256:<hex>`` (key-matching only)
        ``encrypt``           – AES-256-GCM envelope encryption
    NS_PROBE_PHI_SENSITIVE_KEYS_FILE:
        Path to a newline-delimited file of sensitive key patterns.
    NS_PROBE_PHI_ENTITIES:
        Comma-separated Presidio entity list override.
    NS_PROBE_PHI_SPACY_MODEL:
        spaCy model override (default ``en_core_web_sm``).
    NS_PROBE_PHI_SCORE_THRESHOLD:
        Minimum Presidio confidence score (default ``0.4``).

Thread Safety:
    The sanitizer is called from the exporter daemon thread.
    Configuration is read-only after ``configure_phi()`` completes.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, FrozenSet, List, Optional, Set

logger = logging.getLogger("ns_probe.phi_sanitizer")

# ── Presidio availability probe (import-time, zero cost if absent) ────
_PRESIDIO_AVAILABLE = False
try:
    import presidio_analyzer  # noqa: F401
    import presidio_anonymizer  # noqa: F401
    _PRESIDIO_AVAILABLE = True
except ImportError:
    pass

# ── Default sensitive keys ────────────────────────────────────────────
# This list covers common HIPAA identifiers.  It is intentionally broad
# so that a new deployment is safe by default; production teams can
# narrow it via configuration.
DEFAULT_SENSITIVE_KEYS: FrozenSet[str] = frozenset({
    # Patient identifiers
    "patient_name",
    "patient_id",
    "first_name",
    "last_name",
    "full_name",
    "name",
    # Government IDs
    "ssn",
    "social_security",
    "social_security_number",
    # Dates
    "dob",
    "date_of_birth",
    "birth_date",
    # Contact information
    "phone",
    "phone_number",
    "email",
    "email_address",
    "address",
    "street_address",
    "zip_code",
    "postal_code",
    # Medical record identifiers
    "mrn",
    "medical_record_number",
    "insurance_id",
    "policy_number",
    # Biometric / clinical (attribute-level)
    "blood_type",
    "diagnosis",
    "prescription",
})


class SanitizationStrategy(str, Enum):
    """How to replace sensitive values."""
    REDACT = "redact"    # → "[REDACTED]" / "<PERSON>" etc.
    HASH = "hash"        # → "sha256:<hex>" (key-matching only)
    ENCRYPT = "encrypt"  # → "ns_enc_v1:<iv>:<ct>" (envelope encryption)


class PHIEngine(str, Enum):
    """Which engine performs the actual detection."""
    PRESIDIO = "presidio"  # NLP-based (Microsoft Presidio + spaCy)
    KEYS = "keys"          # Regex key-matching (lightweight fallback)


REDACTED_PLACEHOLDER = "[REDACTED]"


@dataclass
class PHISanitizerConfig:
    """Runtime-immutable configuration for PHI sanitization."""
    enabled: bool = False
    engine: PHIEngine = PHIEngine.PRESIDIO
    # Key-matching settings (used when engine == KEYS)
    sensitive_keys: FrozenSet[str] = field(default_factory=lambda: DEFAULT_SENSITIVE_KEYS)
    strategy: SanitizationStrategy = SanitizationStrategy.REDACT
    # Compiled regex patterns derived from sensitive_keys (built once)
    _patterns: Optional[re.Pattern] = field(default=None, repr=False)

    def __post_init__(self) -> None:
        # Build a single compiled regex that matches any sensitive key
        # as a *substring* of the attribute key (case-insensitive).
        if self.sensitive_keys:
            escaped = [re.escape(k) for k in sorted(self.sensitive_keys)]
            self._patterns = re.compile("|".join(escaped), re.IGNORECASE)
        else:
            self._patterns = None


# ── Module-level singleton ────────────────────────────────────────────

_config: Optional[PHISanitizerConfig] = None


def _load_keys_from_file(path: str) -> Set[str]:
    """Load sensitive keys from a newline-delimited text file."""
    keys: Set[str] = set()
    try:
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                stripped = line.strip()
                if stripped and not stripped.startswith("#"):
                    keys.add(stripped.lower())
    except OSError as exc:
        logger.warning("Could not read PHI keys file %s: %s", path, exc)
    return keys


def get_phi_config() -> PHISanitizerConfig:
    """Return the current PHI config, creating from env if needed."""
    global _config
    if _config is None:
        _config = _build_config_from_env()
    return _config


def _build_config_from_env() -> PHISanitizerConfig:
    """Build PHI config from environment variables + defaults."""
    enabled = os.getenv("NS_PROBE_PHI_ENABLED", "false").lower() in ("true", "1", "yes")

    # Engine selection
    engine_str = os.getenv("NS_PROBE_PHI_ENGINE", "").lower()
    if engine_str == "keys":
        engine = PHIEngine.KEYS
    elif engine_str == "presidio":
        engine = PHIEngine.PRESIDIO
    else:
        # Auto-detect: use Presidio if available, else fall back to keys
        engine = PHIEngine.PRESIDIO if _PRESIDIO_AVAILABLE else PHIEngine.KEYS

    # Merge sources: defaults ← file ← env-var list
    keys: Set[str] = set(DEFAULT_SENSITIVE_KEYS)

    keys_file = os.getenv("NS_PROBE_PHI_SENSITIVE_KEYS_FILE")
    if keys_file:
        keys |= _load_keys_from_file(keys_file)

    keys_env = os.getenv("NS_PROBE_PHI_SENSITIVE_KEYS")
    if keys_env:
        keys |= {k.strip().lower() for k in keys_env.split(",") if k.strip()}

    strategy_str = os.getenv("NS_PROBE_PHI_STRATEGY", "redact").lower()
    try:
        strategy = SanitizationStrategy(strategy_str)
    except ValueError:
        logger.warning("Unknown PHI strategy '%s', falling back to 'redact'", strategy_str)
        strategy = SanitizationStrategy.REDACT

    return PHISanitizerConfig(
        enabled=enabled,
        engine=engine,
        sensitive_keys=frozenset(keys),
        strategy=strategy,
    )


def configure_phi(
    *,
    enabled: Optional[bool] = None,
    engine: Optional[str] = None,
    sensitive_keys: Optional[List[str]] = None,
    strategy: Optional[str] = None,
) -> PHISanitizerConfig:
    """
    Programmatically configure PHI sanitization.

    Call this **before** any spans are created (typically right after
    ``ns_probe.configure()``).

    Args:
        enabled:  Master on/off switch.
        engine:   ``"presidio"`` (NLP) or ``"keys"`` (regex key-matching).
                  Defaults to ``"presidio"`` when libs are installed.
        sensitive_keys:  Full *replacement* list of sensitive attribute keys
                         (only used by the ``keys`` engine).  Pass ``None``
                         to keep the current list.
        strategy: ``"redact"``, ``"hash"``, or ``"encrypt"``.
                  ``"encrypt"`` uses AES-256-GCM envelope encryption.

    Returns:
        The active PHISanitizerConfig.
    """
    global _config
    cfg = get_phi_config()

    new_enabled = enabled if enabled is not None else cfg.enabled

    if engine is not None:
        try:
            new_engine = PHIEngine(engine.lower())
        except ValueError:
            raise ValueError(
                f"Invalid PHI engine: {engine!r}.  Use 'presidio' or 'keys'."
            )
        if new_engine is PHIEngine.PRESIDIO and not _PRESIDIO_AVAILABLE:
            raise ImportError(
                "Presidio engine requested but presidio-analyzer / presidio-anonymizer "
                "are not installed.  Install with: pip install 'ns_probe[phi]'"
            )
    else:
        new_engine = cfg.engine

    new_keys = frozenset(k.lower() for k in sensitive_keys) if sensitive_keys is not None else cfg.sensitive_keys

    if strategy is not None:
        try:
            new_strategy = SanitizationStrategy(strategy.lower())
        except ValueError:
            raise ValueError(
                f"Invalid PHI strategy: {strategy!r}.  Use 'redact', 'hash', or 'encrypt'."
            )
    else:
        new_strategy = cfg.strategy

    _config = PHISanitizerConfig(
        enabled=new_enabled,
        engine=new_engine,
        sensitive_keys=new_keys,
        strategy=new_strategy,
    )

    # If encrypt strategy is selected, initialise the CryptoEngine
    if new_enabled and new_strategy is SanitizationStrategy.ENCRYPT:
        from .crypto import get_crypto_engine, init_crypto_engine, _CRYPTO_AVAILABLE

        if not _CRYPTO_AVAILABLE:
            raise ImportError(
                "encrypt strategy requires the 'cryptography' package. "
                "Install with:  pip install 'ns_probe[phi]'"
            )
        if get_crypto_engine() is None:
            init_crypto_engine()

    logger.info(
        "PHI sanitizer configured: enabled=%s, engine=%s, strategy=%s, keys=%d",
        _config.enabled, _config.engine.value, _config.strategy.value,
        len(_config.sensitive_keys),
    )
    return _config


def reset_phi_config() -> None:
    """Reset to defaults (primarily for tests)."""
    global _config
    _config = None
    # Also reset singletons so next configure_phi starts fresh
    try:
        from .presidio_redactor import PresidioRedactor
        PresidioRedactor.reset()
    except ImportError:
        pass
    try:
        from .crypto import reset_crypto_engine
        reset_crypto_engine()
    except ImportError:
        pass


# ── Core sanitization helpers ─────────────────────────────────────────

def _hash_value(value: Any) -> str:
    """Deterministic SHA-256 hash prefixed with ``sha256:``."""
    raw = str(value).encode("utf-8")
    return f"sha256:{hashlib.sha256(raw).hexdigest()}"


def _is_sensitive_key(key: str, pattern: Optional[re.Pattern]) -> bool:
    """Return True if *key* matches any sensitive pattern."""
    if pattern is None:
        return False
    return pattern.search(key) is not None


def sanitize_value(value: Any, strategy: SanitizationStrategy) -> Any:
    """Replace a single value according to *strategy*."""
    if strategy is SanitizationStrategy.HASH:
        return _hash_value(value)
    return REDACTED_PLACEHOLDER


# ── Public API: sanitize a dict of attributes ─────────────────────────

def sanitize_attributes(attrs: Dict[str, Any]) -> Dict[str, Any]:
    """
    Return a *new* dict with sensitive values replaced.

    If PHI sanitization is disabled the original dict is returned
    unchanged (zero overhead).

    Dispatches to the configured engine:
    - **presidio**: every string value (including JSON-embedded) is run
      through NLP-based entity detection.
    - **keys**: only values whose attribute key matches the sensitive-key
      regex are replaced.
    """
    cfg = get_phi_config()
    if not cfg.enabled or not attrs:
        return attrs

    if cfg.engine is PHIEngine.PRESIDIO:
        return _sanitize_attrs_presidio(attrs)
    return _sanitize_attrs_keys(attrs, cfg)


# ── Presidio engine ───────────────────────────────────────────────────

def _sanitize_attrs_presidio(attrs: Dict[str, Any]) -> Dict[str, Any]:
    """Sanitize every attribute value using Presidio NLP."""
    from .presidio_redactor import sanitize_payload, PresidioRedactor

    cfg = get_phi_config()
    strategy = cfg.strategy.value  # "redact" or "encrypt"

    crypto_engine = None
    if cfg.strategy is SanitizationStrategy.ENCRYPT:
        from .crypto import get_crypto_engine
        crypto_engine = get_crypto_engine()
        if crypto_engine is None:
            logger.warning(
                "encrypt strategy requested but CryptoEngine not initialised; "
                "falling back to redact"
            )
            strategy = "redact"
            crypto_engine = None

    redactor = PresidioRedactor.get_instance(
        strategy=strategy,
        crypto_engine=crypto_engine,
    )
    sanitized: Dict[str, Any] = {}
    for key, value in attrs.items():
        sanitized[key] = sanitize_payload(value, redactor)

    # Inject the encrypted DEK so downstream systems can decrypt
    if crypto_engine is not None:
        sanitized["ns.crypto.encrypted_dek"] = crypto_engine.get_encrypted_dek()

    return sanitized


# ── Key-matching engine (original, lightweight) ───────────────────────

def _sanitize_attrs_keys(attrs: Dict[str, Any], cfg: PHISanitizerConfig) -> Dict[str, Any]:
    """Sanitize based on attribute-key regex matching."""
    sanitized = {}
    for key, value in attrs.items():
        if _is_sensitive_key(key, cfg._patterns):
            sanitized[key] = sanitize_value(value, cfg.strategy)
        elif isinstance(value, str):
            sanitized[key] = _sanitize_json_string(value, cfg)
        else:
            sanitized[key] = value
    return sanitized


def _sanitize_json_string(value: str, cfg: PHISanitizerConfig) -> str:
    """If *value* looks like a JSON object, sanitize keys inside it."""
    if not value or value[0] not in ("{", "["):
        return value
    try:
        parsed = json.loads(value)
    except (json.JSONDecodeError, ValueError):
        return value

    changed = _sanitize_nested(parsed, cfg)
    return json.dumps(changed, default=str)


def _sanitize_nested(obj: Any, cfg: PHISanitizerConfig) -> Any:
    """Recursively sanitize dicts/lists."""
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if _is_sensitive_key(k, cfg._patterns):
                out[k] = sanitize_value(v, cfg.strategy)
            else:
                out[k] = _sanitize_nested(v, cfg)
        return out
    if isinstance(obj, list):
        return [_sanitize_nested(item, cfg) for item in obj]
    return obj
